/**
 * Rev.0:01.02.2020>00:24:21>
 * Rev.1:01.02.2020>16:00:39>
 * Rev.2:03.02.2020>11:49:~~>
 * Rev.3:25.03.2020>22:19:~~>
 * Rev.4:01.04.2020>22:11:~~>added>video>startrek>warp
**/
	const APP_NAME='[video]::';
	const VIDEO_WIDTH=400,VIDEO_HEIGHT=VIDEO_WIDTH*(400/600);
	const MP3='.mp3';const MP4='.mp4';const AVI='.avi';
	const M4V='.m4v';
	const rootVideo="../../videos/";
	/**VIDEOS-DOCS*/
	/**VIDEOS-DOCS*/
	/**VIDEOS-DOCS*/
	// const URL_EARTH_DOCUMENTARY="file:///D:/Users/Kais/videos/EARTH-TV/EARTH-DOCUMENTARY/";
	const URL_EARTH_DOCUMENTARY=rootVideo+"docs/";
	const VID_GREC			="ZA1-Ils_ont_change_le_monde-Les_Grecs"+MP4;
	const VID_ROMA			="ZB2-Rome_toute_l'histoire-Documentaire-2017-high"+MP4;
	const VID_PETRA			="ZC1-Petra_au_royaume_des_femmes"+MP4;
	const VID_ARABE			="ZC2-Ils_ont_changé_le_monde-Les_Arabes"+MP4;
	/**URLS->PHLETON-CINEMA*/
	/**URLS->PHLETON-CINEMA*/
	// const URL_PHLETON_CINEMA="file:///D:/Users/Kais/videos/@PHLETON-CINEMA/";
	const URL_PHLETON_CINEMA=rootVideo+"pcinema/";
	function getURLPhletonCinema(year){
		var url=URL_PHLETON_CINEMA+"PHLETON-CINEMA-"+year+"/";
		return url;
	}
	const URL_PHCINEMA2016	=getURLPhletonCinema(2016);
	const URL_PHCINEMA2017	=getURLPhletonCinema(2017);
	const URL_PHCINEMA2018	=getURLPhletonCinema(2018);
	const URL_PHCINEMA2019	=getURLPhletonCinema(2019);
	const URL_PHCINEMA2020	=getURLPhletonCinema(2020);
	/**URLS->AISA*/
	/**URLS->AISA*/
	/**URLS->AISA*/
	function getURL_AISA(year){const URL_AISA="file:///L:/kaisel/videos/aisa/";
		// var url=URL_AISA+"AISA-"+year+"/";
		var url=URL_AISA;
		return url;
	}
	const URL_AISA2017=getURL_AISA(2017);const URL_AISA2018=getURL_AISA(2018);
	const URL_AISA2019=getURL_AISA(2019);const URL_AISA2020=getURL_AISA(2020);
	const URL_AISA2021=getURL_AISA(2021);const URL_AISA2022=getURL_AISA(2022);
	const URL_AISA2023=getURL_AISA(2023);const URL_AISA2024=getURL_AISA(2024);
	const VID_AISA201701	="AISA-INTRO-2017-01"+MP4;
	const VID_AISA201702	="AISA-INTRO-2017-02"+MP4;
	const VID_AISA201801	="AISA-INTRO-2018-01"+MP4;
	const VID_AISA201802	="AISA-2018-MAKE-BOTTLE-FLY"+MP4;
	const VID_AISA201901	="AISA-INTRO-2019"+MP4;
	const VID_AISA202001	="AISA-INTRO-2020"+MP4;
	/**UnitedEARTH*/
	/**UnitedEARTH*/
	const URL_UEM=rootVideo+"uem/";
	const VID_UNITEDEARTH01	="UNITED-PLANET-EARTH-TRAILER"+MP4;
	const VID_UNITEDEARTH02	="UNITED-PLANET-EARTH-E02-final"+MP4;
	/**STARTREK*/
	/**STARTREK*/
	/**STARTREK*/
	/**STARTREK*/
	const URL_STARTREK=rootVideo+"startrek/";
	const VID_BEYOND1	="Star Trek Beyond - Trailer (2016) - Paramount Pictures"+MP4;
	const VID_BEYOND2	="Star Trek Beyond Trailer 2 (2016) - Paramount Pictures"+MP4;
	const VID_EPIC		="Star Trek Epic Music Suite Where No One Has Gone Before"+MP4;
	const VID_BODLYGO	="To Boldly Go Where No Man Has Gone Before - Star Trek (99) M"+MP4;
	const VID_WARP      ="Star Trek 2009 Intro and Warp"+MP4;
	const VID_HIKAYET_EP01="Hikayet-KaiselKara-ep01"+MP4;
	/**NEWSTIME*/
	/**NEWSTIME*/
	const URL_NEWSTIME=rootVideo+"newstime/";
	const VID_NEWSTIME00	="ant-official"+MP4;
	const VID_NEWSTIME01	="ant-2017-09-preview-classic"+MP4;
	const VID_NEWSTIME02	="ant-2017-09-preview-nightly"+MP4;
	/**TRAILERS*/
	/**TRAILERS*/
	/**TRAILERS*/
	// const URL_TRAILER		="file:///D:/Users/Kais/videos/@TRAILERS/";
	const URL_TRAILER	=rootVideo+"trailers/";
	const URL_BAYWATCH	="D:/Windos/users/baywatch/";
	const VID_ARABOISL	="earth-documentar-intro-araboisl"+MP4;
	const VID_BAYWATCH	="earth-documentar-intro-baywatch"+MP4;
	const VID_GREECE	="earth-documentar-intro-greece"+AVI;
	const VID_ROME		="earth-documentar-intro-roma"+MP4;
	/**VIDEOS-MUSIC*/
	/**VIDEOS-MUSIC*/
	/**VIDEOS-MUSIC*/
	const URL_MUSIC		=rootVideo+"music/";
	const VID_MUSIC00=""+MP4;
	const VID_MUSIC01="WORLDMUSIC-EP01"+M4V;
	const VID_MUSIC02="WORLDMUSIC-EP02-small"+M4V;
	const VID_MUSIC03="WORLDMUSIC-EP03-2016-12-08-21h33m38s"+MP4;
	const VID_MUSIC04="WORLDMUSIC-EP04"+MP4;
	const VID_MUSIC05="WORLDMUSIC-EP05-2016-09-28-20h58m14s"+MP4;
	const VID_MUSIC06=""+MP4;
	/**VIDEOS-MOVIES*/
	/**VIDEOS-MOVIES*/
	/**VIDEOS-MOVIES*/
	const URL_MOVIE		=rootVideo+"movies/";
	const VID_ANGELINA	="Angelina-Jolie-7_jours_et_une_vie"+AVI;
	const VID_SUPERGIRL	="My.Super.Ex.Girlfriend.FRENCH.TS.XViD-VCDFRV_ALLTEAM"+AVI;
	/**VIDEOS-SERIES*/
	/**VIDEOS-SERIES*/
	/**VIDEOS-SERIES*/
	const URL_SERIE		=rootVideo+"series/";
	const VID_SERIE01="Code Quantum - Generique"+MP4;
	const VID_SERIE02="Dean Cain is Superman"+MP4;
	const VID_SERIE03="Hercule Générique de début VF"+MP4;
	const VID_SERIE04="Xena - generique HQ (saison 1)"+MP4;
	const VID_SERIE05="Sleeping In Light - last 5 minutes of Babylon 5"+MP4;
	const VID_SERIE06="The Matrix (1999) - The Pill scene"+MP4;
	const VID_SERIE07="Blue Pill or Red Pill - The Matrix (2%2F9) Movie CLIP (1999) HD"+MP4;
	const VID_SERIE08=""+MP4;
	const VID_SERIE09=""+MP4;
	const VID_SERIE10=""+MP4;
	/**VIDEOS-COMEDY*/
	/**VIDEOS-COMEDY*/
	const URL_COMEDY=rootVideo+"comedy/";
	const VID_COMEDY00="قناة الملكة، ماذا حصل عندما قابل عادل إمام مريم بن مولاهم؟_x264"+MP4;
	const VID_COMEDY01="phleton-funny-foutacagoule"+MP4;
	const VID_COMEDY02="tunisair-ep05-frankfurtenvol-preview"+MP4;
	const VID_COMEDY03=""+MP4;
	const VID_COMEDY04=""+MP4;
	const VID_COMEDY05=""+MP4;
	const VID_COMEDY06=""+MP4;
	const VID_COMEDY07=""+MP4;
	/**VIDEOS-POLITICS*/
	/**VIDEOS-POLITICS*/
	/**VIDEOS-POLITICS*/
	/**VIDEOS-POLITICS*/
	/**VIDEOS-POLITICS*/
	/**VIDEOS-POLITICS*/
	const URL_POLITIC=rootVideo+"politics/";
	const VID_POLITIC00="الحزب الدستوري الديمقراطي الثالث، بداية الكفاح-final"+MP4;
	const VID_POLITIC01="Episode 01 (الحزب الدستوري الديمقراطي الثالث)"+MP4;
	const VID_POLITIC02="Episode 02 (الحزب الدستوري الديمقراطي الثالث)"+MP4;
	const VID_POLITIC03="Episode 03 (الحزب الدستوري الديمقراطي الثالث)"+MP4;
	const VID_POLITIC04="Episode 04 (الحزب الدستوري الديمقراطي الثالث)"+MP4;
	const VID_POLITIC05="Episode 05 (الحزب الدستوري الديمقراطي الثالث)"+MP4;
	const VID_POLITIC06="Episode 06 (الحزب الدستوري الديمقراطي الثالث)"+MP4;