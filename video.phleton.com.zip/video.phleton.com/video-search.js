/**video-search.js*/	
/**video-search.js*/	
/**video-search.js*/
/**
 * Rev.0:01.02.2020>01:35:55>
 * Rev.1:01.02.2020>16:00:46>
 * Rev.2:03.02.2020>11:52:~~>
 * Rev.3:25.03.2020>22:19:~~>
 * Rev.4:01.04.2020>22:11:~~>added>video>startrek>warp
**/
	/**SEARCH*/
	function search(query){var url='';
		appInfo('received->Query->'+query);
		// if(query.substring(0,6)=='doc?q=')		{return searchVideo4Documentary(query);}
		if(query.substring(0,3+3)=='doc?q='){return searchDocumentary(query);}
		if(query.substring(0,3+3)=='uem?q='){return searchUnitedEarth(query);}
		if(query.substring(0,3+4)=='aisa?q='){return searchAISA(query);}
		if(query.substring(0,3+5)=='movie?q='){return searchMovie(query);}
		if(query.substring(0,3+5)=='serie?q='){return searchSerie(query);}
		if(query.substring(0,3+5)=='music?q='){return searchMusic(query);}
		if(query.substring(0,3+6)=='comedy?q='){return searchComedy(query);}
		if(query.substring(0,3+7)=='trailer?q='){return searchTrailer(query);}
		if(query.substring(0,3+7)=='politic?q='){return searchPolitic(query);}
		if(query.substring(0,3+8)=='startrek?q='){return searchStartrek(query);}
		if(query.substring(0,3+8)=='newstime?q='){return searchNewstime(query);}
		return videoPath;
	}
	function searchTrailer(query){var searchVid='',videoName='',videoURL='';
		if(query.substring(0,10)=='trailer?q='){
			searchVid=query.substring(10,query.length);
			const vids=[VID_ARABOISL,VID_BAYWATCH,VID_GREECE,VID_ROME];
			//appInfo('query->substring->'+searchVid);
			if(searchVid=='araboisl'){videoName=vids[0];}
			if(searchVid=='baywatch'){videoName=vids[1];}
			if(searchVid=='greece'){videoName=vids[3];}
			if(searchVid=='rome'){videoName=vids[3];}
			videoURL=URL_TRAILER+videoName;
			appInfo('videoName:['+videoName+']');//||videoURL:['+videoURL+']');
			return videoURL;
		}
	}
	function searchAISA(query){var searchVid='',videoName='',videoURL='';
		if(query.substring(0,3+4)=='aisa?q='){
			searchVid=query.substring(3+4,query.length);
			const vids=[VID_AISA201701,VID_AISA201702,
			VID_AISA201801,VID_AISA201802,
			VID_AISA201901,VID_AISA202001
			];
			//appInfo('query->substring->'+searchVid);
			if(searchVid=='aisa201701'){videoName=vids[0];}
			if(searchVid=='aisa201702'){videoName=vids[1];}
			if(searchVid=='aisa201801'){videoName=vids[2];}
			if(searchVid=='aisa201802'){videoName=vids[3];}
			if(searchVid=='aisa201901'){videoName=vids[4];}
			if(searchVid=='aisa202001'){videoName=vids[5];}
			videoURL=getURL_AISA(2020)+videoName;
			appInfo('videoName:['+videoName+']');//||videoURL:['+videoURL+']');
			return videoURL;
		}
	}
	function searchMovie(query){var searchVid='',videoName='',videoURL='';
		if(query.substring(0,3+5)=='movie?q='){
			searchVid=query.substring(3+5,query.length);
			const vids=[VID_ANGELINA,VID_SUPERGIRL];
			//appInfo('query->substring->'+searchVid);
			if(searchVid=='angelina'){videoName=vids[0];}
			if(searchVid=='supergirl'){videoName=vids[1];}
			videoURL=URL_MOVIE+videoName;
			appInfo('videoName:['+videoName+']');//||videoURL:['+videoURL+']');
			return videoURL;
		}
	}
	function searchSerie(query){var searchVid='',videoName='',videoURL='';
		if(query.substring(0,3+5)=='serie?q='){
			searchVid=query.substring(3+5,query.length);
			const vids=[VID_SERIE01,VID_SERIE02,VID_SERIE03,VID_SERIE04,VID_SERIE05
			,VID_SERIE06,VID_SERIE07];
			//appInfo('query->substring->'+searchVid);
			if(searchVid=='quantum'){videoName=vids[0];}
			if(searchVid=='superman'){videoName=vids[1];}
			if(searchVid=='hercule'){videoName=vids[2];}
			if(searchVid=='xena'){videoName=vids[3];}
			if(searchVid=='babylon'){videoName=vids[4];}
			if(searchVid=='matrix'){videoName=vids[5];}
			videoURL=URL_SERIE+videoName;
			appInfo('videoName:['+videoName+']');//||videoURL:['+videoURL+']');
			return videoURL;
		}
	}
	function searchMusic(query){var searchVid='',videoName='',videoURL='';
		if(query.substring(0,3+5)=='music?q='){
			searchVid=query.substring(3+5,query.length);
			const vids=[VID_MUSIC01,VID_MUSIC01,VID_MUSIC02,VID_MUSIC03,VID_MUSIC04,VID_MUSIC05];
			//appInfo('query->substring->'+searchVid);
			if(searchVid=='ep0'){videoName=vids[0];}
			if(searchVid=='ep1'){videoName=vids[1];}
			if(searchVid=='ep2'){videoName=vids[2];}
			if(searchVid=='ep3'){videoName=vids[3];}
			if(searchVid=='ep4'){videoName=vids[4];}
			if(searchVid=='ep5'){videoName=vids[5];}
			videoURL=URL_MUSIC+videoName;
			appInfo('videoName:['+videoName+']');//||videoURL:['+videoURL+']');
			return videoURL;
		}
	}
	function searchStartrek(query){var searchVid='',videoName='',videoURL='';
		if(query.substring(0,3+8)=='startrek?q='){
			searchVid=query.substring(3+8,query.length);
			const vids=[VID_BEYOND1,VID_BEYOND2,VID_EPIC,VID_BODLYGO,VID_WARP,VID_HIKAYET_EP01];
			//appInfo('query->substring->'+searchVid);
			if(searchVid=='beyond1'){videoName=vids[0];}
			if(searchVid=='beyond2'){videoName=vids[1];}
			if(searchVid=='epic')   {videoName=vids[2];}
			if(searchVid=='bodlygo'){videoName=vids[3];}
			if(searchVid=='warp')   {videoName=vids[4];}
			if(searchVid=='hikayetEP01')   {videoName=vids[5];}
			videoURL=URL_STARTREK+videoName;
			appInfo('videoName:['+videoName+']');//||videoURL:['+videoURL+']');
			return videoURL;
		}
	}
	function searchUnitedEarth(query){
		var searchVid='',videoName='',videoPath='';
		if(query.substring(0,6)=='uem?q='){
			videoPath=URL_UEM;
			searchVid=query.substring(6,query.length);
			if(searchVid=='uep0')	{videoName=VID_UNITEDEARTH01;}
			if(searchVid=='uep1')	{videoName=VID_UNITEDEARTH02;}
			if(searchVid=='nx01')	{videoPath=URL_PHCINEMA2020;
				videoName=VIDEONAME_ARABE_NX01;
				videoPath+=videoName;
				appInfo('videoName:['+videoName+']');//||videoPath:['+videoPath+']');
				return videoPath;
			}
			videoPath+=videoName;
			appInfo('videoName:['+videoName+']');//||videoPath:['+videoPath+']');
			return videoPath;
		}
	}
	function searchNewstime(query){var searchVid='',videoName='',videoPath='';
		if(query.substring(0,3+8)=='newstime?q='){
			searchVid=query.substring(3+8,query.length);
			if(searchVid=='ep0')	{videoName=VID_NEWSTIME00;}
			if(searchVid=='ep1')	{videoName=VID_NEWSTIME01;}
			if(searchVid=='ep2')	{videoName=VID_NEWSTIME02;}
			videoPath=URL_NEWSTIME+videoName;
			appInfo('videoName:['+videoName+']');//||videoPath:['+videoPath+']');
			return videoPath;
		}
	}
	function searchDocumentary(query){var searchVid='',videoName='',videoPath='';
		if(query.substring(0,3+3)=='doc?q='){
			searchVid=query.substring(3+3,query.length);
			// appInfo('query->substring->'+searchVid);
			const vids=[VID_ROMA,VID_GREC,VID_PETRA,VID_ARABE];
			if(searchVid=='roma')	{videoName=vids[0];}
			if(searchVid=='grec')	{videoName=vids[1];}
			if(searchVid=='petra')	{videoName=vids[2];}
			if(searchVid=='arabe')	{videoName=vids[3];}
			// if(searchVid=='arabe2')	{videoName=VIDEONAME_ARABE_NX01;}
			if(searchVid=='aisa')	{return URL_AISA+VID_AISA;}
			if(searchVid=='baywatch'){return URL_BAYWATCH+VIDEONAME_BAYWATCH02;}
			videoPath=URL_EARTH_DOCUMENTARY+videoName;
			appInfo('videoName:['+videoName+']');//||videoPath:['+videoPath+']');
			return videoPath;
		}
	}
	function searchComedy(query){var searchVid='',videoName='',videoPath='';
		// appInfo('query->substring->'+query.substring(0,9));
		if(query.substring(0,9)=='comedy?q='){
			searchVid=query.substring(9,query.length);
			// appInfo('query->substring->'+searchVid);
			if(searchVid=='ep0')	{videoName=VID_COMEDY00;}
			if(searchVid=='ep1')	{videoName=VID_COMEDY01;}
			if(searchVid=='ep2')	{videoName=VID_COMEDY02;}
			videoPath=URL_COMEDY+videoName;
			appInfo('videoName:['+videoName+']');//||videoPath:['+videoPath+']');
			return videoPath;
		}
	}
	function searchPolitic(query){var searchVid='',videoName='',videoPath='';
		// appInfo('query->substring->'+query.substring(0,10));
		if(query.substring(0,10)=='politic?q='){
			searchVid=query.substring(10,query.length);
			// appInfo('query->substring->'+searchVid);
			if(searchVid=='ep0')	{videoName=VID_POLITIC00;}
			if(searchVid=='ep1')	{videoName=VID_POLITIC01;}
			if(searchVid=='ep2')	{videoName=VID_POLITIC02;}
			if(searchVid=='ep3')	{videoName=VID_POLITIC03;}
			if(searchVid=='ep4')	{videoName=VID_POLITIC04;}
			if(searchVid=='ep5')	{videoName=VID_POLITIC05;}
			if(searchVid=='ep6')	{videoName=VID_POLITIC06;}
			videoPath=URL_POLITIC+videoName;
			appInfo('videoName:['+videoName+']');//||videoPath:['+videoPath+']');
			return videoPath;
		}
	}
/**video-search.js*/	
/**video-search.js*/	
/**video-search.js*/	
