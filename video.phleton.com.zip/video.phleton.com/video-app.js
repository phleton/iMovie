/**
 * Rev.0:01.02.2020>Saturday::1am
 * Rev.0.0:01.02.2020>01:34:19>created>video-app.js
 * Rev.0.1:01.02.2020>01:36:44>saved>video-app.js
 * <hr>
 * Rev.2.0:06.02.2020>13:35:~~>integrate>id>in>video--source
 * Rev.2.0:06.02.2020>13:37:~~>renamed>variable>parent>appVideoNode
 * Rev.2.0:06.02.2020>13:38:~~>renamed>variable>child>appVideoSource
 * Rev.2.0:06.02.2020>13:39:~~>appVideoSource.id='video-source-'+idx;
 * Rev.2.0:06.02.2020>13:39:32>saved
 * <hr>
 * Rev.3.0:13.02.2020>13:48:~~>2videos
 * <hr>
 * Rev.4.0:24.03.2020>09:40:~~>iMovie>
 * Rev.4.1:24.03.2020>12:00:~~>iMovie>
 * Rev.4.2:24.03.2020>21:40:~~>iMovie>added>project>load
 * Rev.4.3:24.03.2020>22:05:~~>iMovie>completed>changes>goalReached
 * <hr>
 * Rev.5.0:xx.02.2020>00:00:~~>
 * Rev.6.0:xx.02.2020>00:00:~~>
 * Rev.7.0:xx.02.2020>00:00:~~>
 * Rev.8.0:xx.02.2020>00:00:~~>
*/
// <!--BEGIN::DOS.js-->
function get(id){return document.getElementById(id)};
// <!-- function getByTag(tagname){return document.getElementsByTagName(tagname)}; -->
function create(tagname){var elem=document.createElement(tagname);return elem;}
function add(oParent,oChild){if(oParent!=null){oParent.appendChild(oChild);}}
// <!--END__::DOS.js-->
function appInfo(msg){console.info(APP_NAME+msg);}
function appError(msg){console.error(APP_NAME+msg);}
function loadApp(){
	document.head.title='PHLETON iMovie 1.0';
	// console.info(document.head);
}
function loadAllProjects(){
	//TODO loading all projects
}
function loadProject(parProjIdentifer){
	if(parProjIdentifer=='documentar')	{loadProjectScene('documentar',arrQuery00);}
	if(parProjIdentifer=='trailer')		{loadProjectScene('trailer	',arrQuery01);}
	if(parProjIdentifer=='codequantum')	{loadProjectScene('codequantum',arrQuery02);}
	if(parProjIdentifer=='politic')		{loadProjectScene('politic	',arrQuery03);}
	if(parProjIdentifer=='comedy')		{loadProjectScene('comedy	',arrQuery04);}
	if(parProjIdentifer=='unitedearth')	{loadProjectScene('unitedearth',arrQuery05);}
	if(parProjIdentifer=='startrek')	{loadProjectScene('startrek	',arrQuery06);}
	if(parProjIdentifer=='newstime')	{loadProjectScene('newstime	',arrQuery07);}
	if(parProjIdentifer=='series')		{loadProjectScene('series	',arrQuery08);}
	if(parProjIdentifer=='music')		{loadProjectScene('music	',arrQuery09);}
	if(parProjIdentifer=='araboisl')	{loadProjectScene('araboisl	',arrQuery10);}
	if(parProjIdentifer=='aisa')		{loadProjectScene('aisa		',arrQuery11);}
}
function loadProjectScene(identifier,arrayOfQuerys){
	var projectContainer=get(identifier.trim());
	console.info(identifier.trim());
	var videoApp=null;
	var numOfVideos=arrayOfQuerys.length;
	for (var i=0;i<numOfVideos;i++){
		var videoURL=search(arrayOfQuerys[i])
		videoApp=loadVideo(i,videoURL);
		add(projectContainer,videoApp);
	}
	if(projectContainer!=null){projectContainer.style.visibility='visible';}
	else{console.error('the project:['+identifier+'] cannot be set to visible')}
}
function loadVideo(idx,videoURL){var appVideoNode=create('video'),appVideoSource=create('source');
	/*video*/appVideoNode.controls=true;
	/*video*/appVideoNode.width=VIDEO_WIDTH;
	/*video*/appVideoNode.height=VIDEO_HEIGHT;
	/*video*/appVideoNode.loop=true;
	/*source*/appVideoSource.id='video-source-'+idx;
	/*source*/appVideoSource.src=videoURL;
	/*source*/add(appVideoNode,appVideoSource);
	return appVideoNode;
}