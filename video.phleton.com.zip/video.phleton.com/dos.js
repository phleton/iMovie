/*DOS-API-1.0-Copyright(c)2013-2020 PHLETON the earth company*/
/**DOM*/
var elem=null;
function create(tagname){elem=document.createElement(tagname);return elem;}
function get(id){elem=getById(id);
	     if(elem==null){elem=getByName(id) ;}
	else if(elem==null){elem=getByTag(id)  ;}
	else if(elem==null){elem=getByTagNS(id);}
	else if(elem==null){elem=getByClass(id);}
	else               {                   ;}
	return elem;}
function getById(id)    {elem=document.getElementById(id);		return elem;}
function getByName(id)  {elem=document.getElementsByName(id);	return elem;}
function getByTag(id)   {elem=document.getElementsByTagName(id);return elem;}
function getByTagNS(id) {elem=document.getElementsByTagNameNS(id);return elem;}
function getByClass(id) {elem=document.getElementsByClassName(id);return elem;}
function add(oParent,oChild){if(oParent!=null){oParent.appendChild(oChild);}}
function write(content)  {return document.write(content);}
function writeln(content){return document.writeln(content);}
/**WINDOW*/
function showMessage(text){window.alert(text);}
function closeWindow(){window.close();}
function createPopup(){window.createPopup();}
function openWindow(url,idx){var targets=['_blank','_parent','_self'];window.open(url,targets[idx]);}
/**WEB*/
function https()    {return 'https://'}
function http()     {return 'http://'}
function w3()       {return 'www.'}
function urlsw(site){return https()+w3()+site+'.com';}/*https://www.site.com*/
function urls1(site){return https()+w3()+site       ;}/*https://www.site    */
function urls(site) {return https()+site+'.com'     ;}/*https://site.com    */
function urlw(site) {return http()+w3()+site+'.com' ;}/*http://www.site.com */
function url(site)  {return http()+site+'.com'      ;}/*http://site.com     */